/**
 * Configuration file for dev environment.
 */

module.exports = {
  port: 8888,

  mongodb: {
    uri: 'mongodb://abc:abc123@ds133398.mlab.com:33398/person'
  }
};
