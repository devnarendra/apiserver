/**
 * Configuration file for dev environment.
 */

module.exports = {
  port: 9999
};
