var config = require('./dev')
  , path = require('path');

module.exports = function (app) {
  app.get('/', function (req, res, next) {
    console.log(path.join(__dirname));
    res.json('First route');
  });

  app.get('/page', function (req, res, next) {
    var filePath = path.join(__dirname + "/../public/view/index.html");
    console.log(filePath)
    res.render(filePath);
  });
}
