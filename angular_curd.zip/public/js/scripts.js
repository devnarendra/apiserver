var myApp = angular.module('crudApp', []);

myApp.controller('ctrl1', function ($scope, $http) {
  refreshData();
  function refreshData() {
    var apiUrl = 'https://personapi.herokuapp.com/person/';
    console.log("calling refreshData - " + apiUrl);
    $http.get(apiUrl).success( function(response) {
      $scope.data = response;
    });
  }

  function clearForm() {
    $scope.per.name = "";
    $scope.per.email = "";
    $scope.per.mobNo = "";
    $scope.per.id = "";
  }

  function success() {
    refreshData();
    clearForm();
  }

  $scope.create = function () {
    var apiUrl = 'https://personapi.herokuapp.com/person/';
    var method = "";
    console.log($scope.per.name);
    if($scope.per.hasOwnProperty('id')) {
      method = "PUT";
      apiUrl = apiUrl + $scope.per.id;
      console.log("apiUrl - -- - " + apiUrl);
    } else {
      method = "POST";
    }

    $http({
      method: method,
      url: apiUrl,
      data: angular.toJson($scope.per),
      header: {
        'Content-Type': 'application/json'
      }
    }).then (success, function (err) {
      alert("Err - " + JSON.stringify(err));
    });
  }

  $scope.edit = function (person) {
    console.log("TRACKING");
    $scope.per = {};
    $scope.per.name = person.name;
    $scope.per.email = person.email;
    $scope.per.mobNo = person.mobNo;
    $scope.per.id = person._id;
  }

  $scope.delete = function (person) {
    var apiUrl = 'https://personapi.herokuapp.com/person/' + person._id;

    $http({
      method: "DELETE",
      url: apiUrl,
    }).then(success, function (err) {
      alert("Failed to delete object");
    });
  }
});
